#!C:\Strawberry\perl\bin

use warnings; #alerts possible typos
use strict; #requires you to declare variable explicitly before using it

print("Hello, World!\n");

my $x = 10;
my $y = 20;
my $s = "Perl string\n";

my $c = $x + $y;

print($s);

print($c." ".$s." ".$x." ".$y."\n");

# with 'use strict;', if you use 'my' keyword to declare variable and try to run the script, Perl
# issues a warning.

my $color = 'red';

print "Your favorite color is ".$color."\n";
#'my' keyword is a lexically scoped variable, this means the variable can only be
#accessed within an enclosed block.  This is the similar to having local vs global variables.
#
#This idea is called scopes.  e.g. PowerShell has a PROCESS SCOPE, MACHINE SCOPE, and USER SCOPE.
#
# example below
{
	my $color = 'blue'; # $color here is limited to this enclosed block
	print "Your favorite color is now ".$color."\n"; # print with the newly defined $color
}
# check to see if we still have $color = 'blue' -  ...it doesn't
#
print "Your favorite color is ".$color.". You see how the color blue was not used here?"."\n";

#in order to make variable declarations that must be explicitly defined with use strict;, 
#you can use 'our' keyword.  It will make the variable a global one.

# example, if you change my $color = 'blue' to our $color = 'blue' (line 31), you will get 'blue' 
# to show up with the print command at line 36.

#Perl interpolates variables using double quotations.

my $amount = 20;
my $S = "The amount is $amount\n";
print($S);

#But, if you use single quotes, it doesn't work.

my $S2 = 'The amount is $amount \n';
print($S2);

#Note that the $amount variable AND the new line operator \n BOTH didn't work

# perl integers are straightforward

my $x = 10;
my $y = 200;
# etc.

#For LARGE integers can use underscores _ as a comma placeholder

my $a = 123_456_789;
print("\n".$a."\n");

#Perl supports integers, strings, binary, octal and hexadecimal number notation
#as well as floating point numbers


# fixed point being  100.25 and Scientific notation as 1.0025e2 or 1.0025E2
print(1.0025E2);

# perl strings can contain ASCII, UNICODE and escape sequence operators/characters such as \n
#
# Strings can be single or double quoted.  single doesn't interpolate, double does
#
# Perl also allows using quote-like operators
# e.g.
#
# The q// acts like single quotes
# qq// acts like double quotes
#


# you can choose any non-alphabetic, non-numeric characters as the delimiters, not just //

my $s = q/"Are you learning Perl string today?" We asked./;
print("\n",$s,"\n");

my $name = 'Jack';
my $s2 = qq/"Are you learning Perl string today?" $name asked./;
print($s2,"\n");


my $s = q^A string with a different delimiter ^;
print($s,"\n");

# can get the string length

my $s = "This is a string\n";
print(length($s),"\n");

# the functions lc() and uc() can be used to change strings in to lower or upper case versions

my $s = "Change cases of a string\n";
print("To upper case:\n");
print(uc($s),"\n");

print("To lower case:\n");
print(lc($s),"\n");

# functions index() and rindex() can be used to search for a string within a string.
# index() searches starting from the first position (can be specificed, default beginning of string) 
# and searches until first occurence of the string is found, its position is given.
# rindex() does same thing but starts search from end of string.


my $s ="Learning Perl is easy";
my $sub = "Perl";
my $p = index($s,$sub); # or rindex($s,$sub);
print(qq\The substring "$sub" found at position "$p" in string "$s"\);

my $s = "Green is my favorite color";
my $color = substr($s,0,5); # Green
my $end = substr($s,-5); # color

print("\n",$end,": ",$color,"\n");

#replace substring

substr($s, 0,5,"Red"); # Red is my favorite color
print($s, "\n");

#Perl operators for arithmetic are nearly same as in python, / * ** + - %
#
#Binary bitwise operations are available for binary number notation

my $a = 0b0101; # 5
my $b = 0b0011; # 3

#and/intesection operator
my $c = $a & $b; # 0001 or 1
print $c, "\n\n";

#union/join operator
my $c = $a | $b; # 0111 or 7
print $c, "\n\n";

#not operator
my $c = $a ^ $b; # 0110 or 6
print $c,"\n\n";

#complement operator
my $c = ~$a; #111111111111111111111111010 (64 bit comp) or 18446744073709551610 
print $c, "\n\n";

#right shift (by 1)
my $c = $a >> 1; # 0010 or 2
print $c, "\n\n";

# left shift (by 1)
my $c = $a << 1; # 1010 or 10
print $c,"\n\n";

# comparison operators  for numbers and strings
#
# equal ==  eq
#
# not equal !=  ne
#
# comparison <=>  cmp
#
# less than < lt
#
# greater than >  gt
#
# less equal <=  le
#
# greater equal >=  ge

#chomp() function removes last character in a string and returns a number of characters that were removed.\

my $s; # declare a variable to be used
chomp($s = <STDIN>); #inside chomp(), the <STDIN> is used to get user input which includes hitting "enter"
                     # or return key.  $s will contain the \n, but chomp will remove that \n entered
print $s;




