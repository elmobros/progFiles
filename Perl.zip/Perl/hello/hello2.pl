#!C:\Strawberry\perl\bin
use warnings;
use strict;

#perl lists simiar to arrays but not quite yet. can list numbers and strings in the same list,
#nested lists just get flattened into a single list.

#Here are some simple lists.

();
(10,20,30);
("This","is","a","list");

#The first list is empty
#The second list is a list of integers
#The third list is a list of strings

#Each element in the list is separated by comma.  We now use print to show the lists.

print(()); # displays nothing
print("\n");
print(10,20,30); # displays 102030
print("\n");
print("this","is","a","list"); # display thisisalist
print("\n");

# comples Perl lists
#

my $x = 10;
my $s = "a string";
print("complex list: ", $x, $s, "\n");

#using qw function

# perl provides the qw() function that allows you to get a list by extractin words out of a string using
# the space as a delimiter.  THe qw stands for quote word.  Two lists below are the same.
#

print('red','green','blue'); # redgreenblue
print("\n");

print(qw(red green blue)); # redgreenblue
print("\n");

# similar to the q/ and q// operators, you can use any non-alphanumeric character as a delimiter.  The 
# following lists are the same:

qw\this is a list\;
qw{this is a list};
qw[this is a list];

# flattening list

(2,3,4,(5,6));
(2,3,4,5,6);
((2,3,4),5,6);
# if you put a list inside another list (internal list) Perl auto flattens the internal list.

# accessing list element(s)

# goes by the (n-1)th index

print(
	(1,2,3)[0] # first element
);
print("\n");

print(
	(1,2,3)[2] # last element
);
print("\n");

# for multiple insstances of elements...

print(
	(1,2,3,4,5)[0,2,3] # (1,3,4)
);
# ranges, Perl allows you to build a list based on a range of numbers or characters e.g. list of numbers from 1 to 100 list of characters from a to z.

#(1..100);
#(a..z);

#Perl Arrays
#
#lists are immutable so you can't change it directly.  
#in order to change a list, you need to store it in an array variable

#by definition, an array is a variable that provides dynamic storage for a list
#
#in perl, the terms array and list are used interchangeably, but there is an important difference:
#a list is immutable, but an array is not.  array's elements can be modified, can grow or shrink array
#but NOT a list
#
#a scalar begins with $ for 's'calar,
#an array begins with @ for 'a'rray
#

my @days = qw(Mon Tue Wed Thu Fri Sat Sun);
print("\n","@days","\n");

# access an array element

print($days[0]);
print("\n");
print($days[2]);
print("\n");

# we used $days[] instead of @days[] because we are accessing an element which is itself a scalar

my @weekend = @days[-2 ..-1]; # SatSun

print("@weekend");
print("\n");

my $count = @days;

print($count,"\n");

my $last = $#days;
print($last,"\n"); # 6

