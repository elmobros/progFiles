"""
Filename: helloworld.py

following tutorialspoint PyQt5 text
"""


import sys
# from PyQt5.QtGui import QApplication
from PyQt5.QtCore import QApplication

def window():

	app = QtGui.QApplication(sys.argv)

	w = QtQui.QWidget()

	b = QtGui.QLabel(w)

	b.setText("Hello World")

	w.setGeometry(100,100,200,50)

	b.move(50,20)

	w.setWindowTitle("PyQt")

	w.show()

	sys.exit(app.exec())

if __name__ == '__main__':
	window()



