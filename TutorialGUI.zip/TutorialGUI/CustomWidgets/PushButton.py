"""
this is a module for a class for QWidget of the form

class PushButton(QPushButton):

	to see how an externally imported, class/custom defined widget can be work

Filename: PushButton.py

Note, to import simple classes, must use this import syntax in the destination file

from FILENAME import CLASSNAME

this should be used if the callback error form building returns

'module is not callable'

"""

import sys
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit, QWidget,
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt
from PyQt5 import QtGui
from PyQt5.QtGui import QFont


class PushButton(QPushButton):
	def __init__(self):
		super(PushButton,self).__init__()

		



	# 	self.initUI()
	# def initUI(self):
	# 	self.btnLabel = "Ext Button"
 #        self.extWidget.setText(self.btnLabel)

        # self.font = QtGui.QFont("Times", 8)
        # self.extWidget.setFont(self.font)
        # self.extWidget.setText(self.btnLabel)



