""" Filename: QLabelButtonPlusClassWidgetAddition.py 

attempting to see how a class defined widget can be imported into current py file
from external py file.

the file ClassWidget.py defines a custom widget and is to be imported into this current file.


"""

import sys 
from PushButton import PushButton 
"""
in order to imnport a script of classes, one must call from FILENAME import CLASSNAME

Not sure why wasn't needed with QMainWindow classes.  Regardless, whn the error
" module is not callable" need to import the script as

" from FILENAME import CLASSNAME "

Otherwise, the basic class definitions (aside from WMainWindow and probably QWidget) must
be written in the SAME script file.


"""


# import ClassWidget
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit, 
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt
from PyQt5 import QtGui
from PyQt5.QtGui import QFont
 

class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()

        # # make container widget
        self.Widget = QWidget()
        # # make a main layout
        self.WidgetmainLayout = QVBoxLayout()

        # window parameters
        self.setWindowTitle("My App")
        self.setGeometry(1000,400,500,500)

        # make the first widget
        self.label = QLabel("Hello")
        font = self.label.font()
        font.setPointSize(30)
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # add Qlabel widget to the layout
        self.WidgetmainLayout.addWidget(self.label)

        # make and add second widget to make sure QVBoxLayout is working
        self.button = QPushButton('OK')
        self.WidgetmainLayout.addWidget(self.button)

        ################################################
        #  Here, we will attempt to add a third widget
        #   via invoking a class
        ################################################

        # Put the class ext widget here
        self.extWidget = PushButton()
        self.btnLabel = "Ext Button"
        font = QtGui.QFont("Times", 8)
        self.extWidget.setFont(font)
        self.extWidget.setText(self.btnLabel)
        # add this widget to the layout
        self.WidgetmainLayout.addWidget(self.extWidget)


        self.Widget.setLayout(self.WidgetmainLayout)
    
        # set alignment for the label and the button
        self.WidgetmainLayout.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # self.setLayout(self.WidgetmainLayout)
        # self.setCentralWidget(self.label)
        self.setCentralWidget(self.Widget)
        


# class PushButton(QPushButton):
#     def __init__(self):
#         super(PushButton,self).__init__()




app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()



