""" Filename: QPlusClass2WidgetAdditions.py 

Needed files:

PushButton.py
customWidget.py

UPDATE:  Now that a custom PushButton class can be imported (described below), this script will 
take another step to see if QWidget class can be imported.

attempting to see how a class defined widget can be imported into current py file
from external py file.

the file ClassWidget.py defines a custom widget and is to be imported into this current file.


"""

import sys 
from PushButton import PushButton
from customWidget import customWidget


"""
in order to imnport a script of classes, one must call from FILENAME import CLASSNAME

Not sure why wasn't needed with QMainWindow classes.  Regardless, whn the error
" module is not callable" need to import the script as

" from FILENAME import CLASSNAME "

Otherwise, the basic class definitions (aside from WMainWindow and probably QWidget) must
be written in the SAME script file.


"""


# import ClassWidget
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit, 
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt
from PyQt5 import QtGui
from PyQt5.QtGui import QFont
 

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        # # make container widget
        self.Widget = QWidget()
        # # make a main layout
        self.WidgetmainLayout = QVBoxLayout()

        # window parameters
        self.setWindowTitle("My App")
        self.setGeometry(1000,400,500,500)

        # make the first widget
        self.label = QLabel("Hello")
        font = self.label.font()
        font.setPointSize(30)
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # add Qlabel widget to the layout
        self.WidgetmainLayout.addWidget(self.label)

        # make and add second widget to make sure QVBoxLayout is working
        self.button = QPushButton('OK')
        self.WidgetmainLayout.addWidget(self.button)

        ################################################
        #  Here, we will attempt to add a third widget
        #   via invoking a class
        ################################################

        # Put the class ext widget here
        self.extWidget = PushButton()
        self.btnLabel = "Ext Button"
        font = QtGui.QFont("Times", 8)
        self.extWidget.setFont(font)
        self.extWidget.setText(self.btnLabel)
        # add this widget to the layout
        self.WidgetmainLayout.addWidget(self.extWidget)


        ################################################
        #  Here, we will attempt to add QWidget custom
        #  class.  ANd then, see is a sub widget can be 
        # further created in the custom QWidget
        ################################################

        self.customWidget = customWidget()

        # self.ext2Widget = customWidget("ext 2", QVBoxLayout())

        # self.ext2Widget = customWidget()  # create instance of the custom QWidget
        # # self.ext2layout = QVBoxLayout()   # make layout for it
        # # self.ext2button = QPushButton("Ext 2")  # create a pushbutton
        # # self.ext2layout.addWidget(self.ext2button)  # add that pushbutton to new layout
        # # self.ext2Widget.setLayout(self.ext2layout) # set the layout of the custom QWidget
        # self.WidgetmainLayout.addWidget(self.ext2Widget)  # add the custom QWidget to main layout

        self.WidgetmainLayout.addWidget(self.customWidget)

        self.Widget.setLayout(self.WidgetmainLayout)
    
        # set alignment for the label and the button
        self.WidgetmainLayout.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # self.setLayout(self.WidgetmainLayout)
        # self.setCentralWidget(self.label)
        self.setCentralWidget(self.Widget)
        

        ################################################
        #  It seems that the QWidget can't have a connecting
        #  signal and slot.  Try to instantiate the button
        # in customWidget.py in this file.  That may allow
        # for a signal and slot
        ################################################


        #  YES, this works, in order to define the button_click,
        # the button from the imported widget must have its signal 
        # and slot instantiated and defined in the destination file
        #
        #Signals and slots for child widgets must be done in their 
        # parent widget where they are to be imported
        
        self.customWidget.button.clicked.connect(self.button_click)

    def button_click(self, checked):
        print("WORKS")


# class PushButton(QPushButton):
#     def __init__(self):
#         super(PushButton,self).__init__()




app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()



