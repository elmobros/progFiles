"""
this is a module for a class for QWidget of the form

class customWidget(QWidget):

	to see how an externally imported, class/custom defined widget can be work

Filename: customWidget.py

Note, to import simple classes, must use this import syntax in the destination file

from FILENAME import CLASSNAME

this should be used if the callback error form building returns

'module is not callable'

"""
 # to add something testable and obvious to see,
   # we will try to define a basic QLabel here in be added to
   # this main widget.


import sys
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit, QWidget, QScrollArea,
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt
from PyQt5 import QtGui
from PyQt5.QtGui import QFont

class customWidget(QWidget):
		def __init__(self):
			

			"""
			Now, try adding a scroll area

			"""
			super().__init__()
			
			self.widgetlayout = QVBoxLayout()

			self.scroll = QScrollArea()
			self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
			self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
			self.scroll.setWidgetResizable(False)

			self.subwidget = QWidget()
			self.subwidgetLayout = QVBoxLayout()


			self.label = QLabel()
			self.text1 = "sit in my chair"
			font = QtGui.QFont("Times",10,QFont.Bold)
			self.label.setFont(font)
			self.label.setText(self.text1)

			self.button = QPushButton("STUFF")
			
			self.subwidgetLayout.addWidget(self.button)
			self.subwidgetLayout.addWidget(self.label)

			self.subwidget.setLayout(self.subwidgetLayout)

			self.scroll.setWidget(self.subwidget)

			self.widgetlayout.addWidget(self.scroll)

			self.setLayout(self.widgetlayout)

			# signals and slots can't be defined in this child widget
			# it must be done in the parent widget

			# self.layout = QVBoxLayout()
			# self.layout.addWidget(self.label)
			# self.setLayout(self.layout)






	#def __init__(self, extLabel, layout):
	#	super(self).__init__()
		# self.extLabel = extLabel
	 #   	self.layout = layout
		# self.layout.addWidget(self.extLabel)
		# self.setLayout(layout)

		# super(customWidget, self).__init__()
	# 	self.initUI()

	# def initUI(self):
	# 	self.extLabel = QLabel("Ext Label")
 #   		self.layout = QVBoxLayout()
	# 	self.layout.addWidget(self.extLabel)
	# 	self.setLayout(layout)




		



