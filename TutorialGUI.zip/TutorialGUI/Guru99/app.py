"""
guru99.com tutorial

filename: app.py

"""

# import sys module, allows command line commands
import sys

# imports the modules needed to create GUI into the current
#  namespace
from PyQt5.QtWidgets import QApplication, QWidget


if __name__ == "__main__":

	# here we create an object of the QApplication class
	# this is needed for every PyQt5, every UI app must
	# create an instance of QApplication
	app = QApplication(sys.argv) # sys.argv allows list of command-line parameters

	# Next, make an object of the QWidget class, QWidget
	# is the base calss of all UI objects in Qt, virtually everything
	# you see in an app is a widget
	w = QWidget()

	# set the dimensions of the widget, i.e., create instance of an attribute
	# of the QWidget() class with the method .resize()
	w.resize(300,300)

	# we set the name of the window with string argument, again another
	# instance of the attribute .setWindowTitle() of the QWidget class
	w.setWindowTitle('Guru69')

	# this method of the .show() for the QWidget() class displays the 
	# widget on the monitor 	
	w.show()

	# the method, app.exec_() or app.exec(), starts the Qt/C++ event loop.
	# .exec() is a method for the QApplication class
	# PyQt is mostly in C++ and uses the event loop mechanism to implement
	# parallel execution.  .exec_() passes the control over to Qt which will
	# exit application only when user clases it from the GUI...
	sys.exit(app.exec_())

	#... that is why ctrl+c will not exit the application as in other python
	# programs.  Since Qt has control over the app, python events are not 
	# procesesed unless we set them up inside the application.  Also, note that
	# the .exec() method has an underscore in its name, this is because exec() was
	# already a keyword in python and the undescore resolves naming conflict.

	#  As long as there is no confusion, you can use .exec() OR .exec_(), at least in
	# this example you can use either.
