"""
guru99.com tutorial

filename: app.py

"""

# import sys module, allows command line commands
import sys

# imports the modules needed to create GUI into the current
#  namespace
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QMessageBox


def dialog():

	# create the object QMessageBox() from the class QMessageBox 
	mbox = QMessageBox()

	# with the method .setText() with the QMessageBox class, we set the text,
	#  set an attribute of the object class QMessageBox
	mbox.setText("Guru 69 is a narcissist")

	# .setDetailedText() method, and defining another attribute
	mbox.setDetailedText("I am not a disciple and subject of the Guru69")

	# using method .setStandardButtons(), we use it to create
	# pre-made/built-in buttons (widgets) for the QMesssageBox object/widget
	mbox.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel )

	# .exec() method of QMessageBox class that runs/displays this object
	mbox.exec()



if __name__ == "__main__":

	# here we create an object of the QApplication class
	# this is needed for every PyQt5, every UI app must
	# create an instance of QApplication
	app = QApplication(sys.argv) # sys.argv allows list of command-line parameters

	# Next, make an object of the QWidget class, QWidget
	# is the base calss of all UI objects in Qt, virtually everything
	# you see in an app is a widget
	w = QWidget()

	# set the dimensions of the widget, i.e., create instance of an attribute
	# of the QWidget() class with the method .resize()
	w.resize(300,300)

	# we set the name of the window with string argument, again another
	# instance of the attribute .setWindowTitle() of the QWidget class
	w.setWindowTitle('Guru69')

	# here, we create an object instance of QLabel()
	# Note that we are passing the QWidget object to this label
	label = QLabel(w)  # also note this avoids needing to setLayout and addWidget
	                    # and avoids .setCentralWidget()

	# use methods in QLabel() to set attributes, such as Text, and position
	label.setText("guru69, lame guru, Buddha is better")
	label.move(100,130)
	
	# method .show() to show this widget
	label.show()

	# creating a QPushButton class object and again, setting the attributes
	# using methods in that class, and then showing this widget
	# note, again, we are passing the QWidget object in the argument for this
	# QPushButton() object
	btn = QPushButton(w)
	btn.setText("Buddha")
	btn.move(110,150)
	btn.show()

	# we know use a method called .clicked.connect() where connect is inherited
	# we pass the userdefined function def dialog to this method
	btn.clicked.connect(dialog)


	# In GUI based applications, functions are executed based on the actions 
	# performed by the user, e.g. mouse hovering over an element, button click/press/release
	#  Those are called EVENTS.  Once app.exec() method is called,
	# control goes to the Qt-event loop.  This event loop is there to 
	# listen for those events and preform actions based on those events

	# whenever an event occurs, it sends out a signal.  e.g. button click,
	# then the button widget will emit signal.  This signal can be connected
	# to python functions (like the dialog function defined above) so that
	# the function is executed when a signal is triggered.
	# Those functions that connect to a signal are called SLOTS in Qt lingo

	#  generally, syntax is widget.signal.connect(slot)

	# this method of the .show() for the QWidget() class displays the 
	# widget on the monitor 	
	w.show()

	# the method, app.exec_() or app.exec(), starts the Qt/C++ event loop.
	# .exec() is a method for the QApplication class
	# PyQt is mostly in C++ and uses the event loop mechanism to implement
	# parallel execution.  .exec_() passes the control over to Qt which will
	# exit application only when user clases it from the GUI...
	sys.exit(app.exec_())

	#... that is why ctrl+c will not exit the application as in other python
	# programs.  Since Qt has control over the app, python events are not 
	# procesesed unless we set them up inside the application.  Also, note that
	# the .exec() method has an underscore in its name, this is because exec() was
	# already a keyword in python and the undescore resolves naming conflict.

	#  As long as there is no confusion, you can use .exec() OR .exec_(), at least in
	# this example you can use either.
