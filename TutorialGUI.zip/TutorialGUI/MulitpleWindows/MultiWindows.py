from PyQt5.QtWidgets import (
	QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget
)
import sys
from random import randint

class AnotherWindow(QWidget):
	"""
	This "window" is a QWidget.  If it has no parent, it
	will appear as a free-floating window as we want.
	"""

	""" we can see that the window is destroyed and created as a new one by labeling it 
	with a randomw number.  And, pushing the mainwindow button again will make
	a new window popup with different label
	"""
	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another Window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)


class MainWindow(QMainWindow):
	""" we can check whether the window has already been created before creating it
	"""
	def __init__(self):
		super().__init__()
		self.w = None # to check widnow aldreay made 
		self.button = QPushButton("Push for Window")
		self.button.clicked.connect(self.show_new_window)
		self.setCentralWidget(self.button)

	"""
	In this definition for showing the new window, the variable 'w' is local to this 
	function.  need to make it self.w
	"""
	def show_new_window(self, checked):
		if self.w is None:  # checking that self.w here; makes same window appear
			self.w = AnotherWindow()
		self.w.show()

	""" this leads to the idea that one may desire an app to open a window 
	and close the same window on demand
	"""

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()
