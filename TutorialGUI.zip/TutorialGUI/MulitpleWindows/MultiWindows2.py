""" you can use the same principle for creating multiple windows,
as long as you keep a reference to the window, things will work as 
expected.  The simplest approach is to create a separate method to toggle the 
display of each of the windows
"""

import sys
from random import randint

from PyQt5.QtWidgets import (
	QApplication,
	QLabel,
	QMainWindow,
	QPushButton,
	QVBoxLayout,
	QWidget
)

class AnotherWindow(QWidget):

	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)

class MainWindow(QMainWindow):
	def __init__(self):
		super().__init__()
		self.window1 = AnotherWindow()
		self.window2 = AnotherWindow()

		# layout for the two buttons
		l = QVBoxLayout()
		
		# button1 to popup window 1
		button1 = QPushButton("Push for window 1")
		button1.clicked.connect(self.toggle_window1)
		l.addWidget(button1)

		# button2 to popup window 2
		button2 = QPushButton("Push for window 2")
		button2.clicked.connect(self.toggle_window2)
		l.addWidget(button2)

		# setting up the mainwindow as a widget and setting its layout
		w = QWidget()
		w.setLayout(l)

		# set this as the central widget for MainWindow
		self.setCentralWidget(w)

		# connect the above signals from buttons 1 and 2 to 
		# slots for the functions toggle_window1 and toggle_window2
	def toggle_window1(self, checked):
		if self.window1.isVisible():
			self.window1.hide()
		else:
			self.window1.show()

	def toggle_window2(self, checked):
		if self.window2.isVisible():
			self.window2.hide()
		else:
			self.window2.show()
""" this code has two buttons that show and hide two separate windows
"""

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()




