""" sometimes you want windows that are there at the startup.  this example does this
and uses .show() to display them when needed

We create our external window in the __init__ block for the Mainwindow, and then
our show_new_window method simply calls self.w.show()
 to dipslay it
 """
from PyQt5.QtWidgets import (QApplication, QMainWindow,
	QPushButton, QLabel, QVBoxLayout, QWidget
)
import sys
from random import randint

class AnotherWindow(QWidget):
	"""
	This windwo is a widget and if no parent will be free floating as we want
	"""
	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another Window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)

class MainWindow(QMainWindow):

	def __init__(self):
		super().__init__()
		self.w = AnotherWindow()
		self.button = QPushButton("Push for Window")
		self.button.clicked.connect(self.show_new_window)
		self.setCentralWidget(self.button)

	def show_new_window(self, checked):
		self.w.show()
	""" the popup window is persistent and clicking the button again 
	does not affect the window- it stays put until user closes it 
	"""


app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()