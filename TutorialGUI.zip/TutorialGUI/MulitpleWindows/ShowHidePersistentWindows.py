""" once yoiu have created a persistent window you can show and hide it without recreating it
 , once hiddne the window still exists, but will nto be visible and accept
 mouse/other input.  however, you can continue to call methods ont he windw and 
 update it's state -- including changing its appearance.  once re-shown, any changes
 will be visible

Below we update the main window to create a toggle_window method which
checks, using .isVisible()
 to see if the window is currently visisble, if not, it's shown using .show()
 if it is already visible, we hide it with .hide()
 """


from PyQt5.QtWidgets import (
	QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget
)
import sys
from random import randint


class AnotherWindow(QWidget):

	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another Window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)


class MainWindow(QMainWindow):

	def __init__(self):
		super().__init__()
		self.w = AnotherWindow()
		self.button = QPushButton("Push for window")
		self.button.clicked.connect(self.toggle_window)
		self.setCentralWidget(self.button)

		""" toggle_window will either show window if hidden or
		hide window if shown, similar to the other example in Multiwindows,
		but this must be a more correct way of "toggling" a window. DIFFERENCE here is
		that the SAME window disappears and reappears
		"""

	def toggle_window(self, checked):
		if self.w.isVisible():
			self.w.hide()
		else:
			self.w.show()

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()