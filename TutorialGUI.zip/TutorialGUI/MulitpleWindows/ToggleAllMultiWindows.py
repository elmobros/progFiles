""" however, you can also create a generic method which handles toggling for all 
windows, the example here shows this in action, using a 'lambda' function
to intercept the signal from each button and pass through the appropriate window. We
can also discard the checked value since we aren't usign it.
"""

import sys
from random import randint

from PyQt5.QtWidgets import (
	QApplication,
	QLabel,
	QMainWindow,
	QPushButton,
	QVBoxLayout,
	QWidget
	)

class AnotherWindow(QWidget):
	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another Window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)

class MainWindow(QMainWindow):
	def __init__(self):
		super().__init__()
		self.window1 = AnotherWindow()
		self.window2 = AnotherWindow()

		# the layout
		l = QVBoxLayout()
		
		# and the buttons
		button1 = QPushButton("Push for window 1")
		button1.clicked.connect(
			lambda checked: self.toggle_window(self.window1)
		)            # using lambda function here
		l.addWidget(button1)

		button2 = QPushButton("Push for window 2")
		button2.clicked.connect(
			lambda checked: self.toggle_window(self.window2)
		)
		l.addWidget(button2)

		# set up mainwindow widget
		w = QWidget()
		w.setLayout(l)
		self.setCentralWidget(w)

	def toggle_window(self, window):
		if window.isVisible():
			window.hide()
		else:
			window.show()

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()

