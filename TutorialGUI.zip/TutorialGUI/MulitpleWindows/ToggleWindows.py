from PyQt5.QtWidgets import (
	QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout,
	QWidget
)
import sys

from random import randint

class AnotherWindow(QWidget):
	"""
	This "window" is a QWidget. If it has no parent, it will
	appear as a free-floating window and user can go back and forth
	between windows
	"""

	def __init__(self):
		super().__init__()
		layout = QVBoxLayout()
		self.label = QLabel("Another Window % d" % randint(0,100))
		layout.addWidget(self.label)
		self.setLayout(layout)


class MainWindow(QMainWindow):

	def __init__(self):
		super().__init__()
		self.w = None # No external window yet.
		self.button = QPushButton("Push for Window")
		self.button.clicked.connect(self.show_new_window)
		self.setCentralWidget(self.button)

	"""
	often you want to toggle the display of a wundow using an action on a toolbar
	or in a menu.  As we previously saw, if no reference to a windwo is kept,
	it will be discarded and closed. we can use this to close a window, replacing the 
	show_new_window method from the previous eamplxe with this...
	"""
	# From previous example
	# def show_new_window(self, checked):
	# 	if self.w is None:
	# 		self.w = AnotherWindow()
	# 	self.w.show()

	# nes definition

	def show_new_window(self, checked):  # this toggles the window to re-appear as a new one 
		if self.w is None:              # when clicking the button in MainWindow
			self.w = AnotherWindow()
			self.w.show()
		else:
			self.w = None # Discard reference, close window

	""" by setting it to any other value that None the window will still
	close, but the if self.w is None test will not pass the next time, we click 
	the button and so we will not be able to recxreate a window.

	This will only work is you hacve not kept a reference to this window somehere else.
	To make sure the window closes regardless, you may want to explivitly call .close() on it.

	The full example is shown in ToggleFullExample.py
	"""		
		

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()

