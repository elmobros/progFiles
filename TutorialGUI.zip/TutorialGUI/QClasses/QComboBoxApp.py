import sys

from PyQt5.QtWidgets import QMainWindow, QCheckBox, QApplication, QComboBox
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.setWindowTitle("My App")

        widget = QComboBox()
        widget.addItems(["One","Two","Three"])
        widget.setEditable(True)
        widget.setInsertPolicy(QComboBox.InsertPolicy.InsertAlphabetically)
        widget.setMaxCount(10)

        #sends the current index (position) of the selected item
        widget.currentIndexChanged.connect(self.index_changed)

        # there is an alternative signal to send the text
        widget.currentTextChanged.connect(self.text_changed)

        self.setCentralWidget(widget)

    def index_changed(self, i):
        print(i)

    def text_changed(self, s):
        print(s)

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()


