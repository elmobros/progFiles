import sys

from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QDialog

class MainWindow(QMainWindow):
	def __init__(self):
		super().__init__()

		self.setWindowTitle("My App")

		button = QPushButton("Press me for a dialog!")
		button.clicked.connect(self.button_clicked)
		self.setCentralWidget(button)

	# in this slot, we passed QMainWindow as the parent for the dialog
	#  making the dialog "modal" meaning, dialog window will block
	# the user from interacting with QMainWindow
	def button_clicked(self, s):  
		print("click", s)         

		# we now add the dialog window with this slot

		dlg = QDialog(self)
		dlg.setWindowTitle("HELLO!")
		dlg.exec()


app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()