import sys
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit,
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt
 

class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()

        # # make container widget
        self.Widget = QWidget()
        # # make a main layout
        self.WidgetmainLayout = QVBoxLayout()

        # window parameters
        self.setWindowTitle("My App")
        self.setGeometry(1000,400,500,500)

        # make the first widget
        self.label = QLabel("Hello")
        font = self.label.font()
        font.setPointSize(30)
        self.label.setFont(font)
        self.label.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # add Qlabel widget to the layout
        self.WidgetmainLayout.addWidget(self.label)

        # make and add second widget to make sure QVBoxLayout is working
        self.button = QPushButton('OK')

        self.WidgetmainLayout.addWidget(self.button)

        self.Widget.setLayout(self.WidgetmainLayout)
        self.WidgetmainLayout.setAlignment(Qt.AlignHCenter | Qt.AlignVCenter)

        # self.setLayout(self.WidgetmainLayout)
        # self.setCentralWidget(self.label)
        self.setCentralWidget(self.Widget)
        


app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()
