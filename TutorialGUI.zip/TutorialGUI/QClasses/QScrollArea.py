from PyQt5.QtWidgets import (
	QWidget, QSlider, QLineEdit, QLabel, QPushButton, QScrollArea,
	QApplication, QHBoxLayout, QVBoxLayout, QMainWindow
)
from PyQt5.QtCore import Qt, QSize
from PyQt5 import QtWidgets, uic
import sys


class MainWindow(QMainWindow):
	"""
	first create the layout hierarchy, at the top level we have our QMainWindow
	which we can set the QScrollArea onto using .setCentralWidget.  This places the
	QScrollArea in the window taking up the entire area
	"""

	def __init__(self):
		super().__init__()
		self.initUI()

	""" 
	to add content to the QScrollArea we nedd to add a widget using .setWidget, 
	in this case we are adding a custom QWidget onto which we have applied a QVBoxLayout
	containing multiple subWidgets
	"""

	def initUI(self):
		""" scroll area which contains the widgets, set as the central widget
		widget that contains the collection of vertical box
		vertical Box that contains the horizontal boxes of labels and buttons
		"""
		self.scroll = QScrollArea()  # this sets the scroll area
		self.widget = QWidget()		# we create a container for the scroll area
		self.vbox = QVBoxLayout()   # we setup a layout to be inside scroll area

		for i in range(1,50):   # these are the mulitple subwidgets being created
			object = QLabel("TextLabel")
			self.vbox.addWidget(object)   # and then added to layout inside QScrollArea

		"""
		since entire window wdiget is scroll area, we then take the vbox layout with all
		the vertical label widgets and this layout to the scroll area
		"""
		self.widget.setLayout(self.vbox) 

		# scroll area properties
		self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)  # this makes vert slider always ON
		self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff) # makes H slider always OFF
		self.scroll.setWidgetResizable(True) # can resize the scroll area
		self.scroll.setWidget(self.widget) # finally set the scroll area 

		self.setCentralWidget(self.scroll)

		self.setGeometry(600,100,1000,900)
		self.setWindowTitle('Scroll Area Demonstration')
		self.show()

		return

def main():
	app = QtWidgets.QApplication(sys.argv)
	main = MainWindow()
	sys.exit(app.exec_())

if __name__ == '__main__':
	main()
