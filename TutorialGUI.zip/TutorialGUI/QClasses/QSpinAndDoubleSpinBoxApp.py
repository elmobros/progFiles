import sys

from PyQt5.QtWidgets import QMainWindow, QDoubleSpinBox, QApplication, QSpinBox
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()

        self.setWindowTitle("My App")

        widget = QSpinBox()
        # or: widget = QDoubleSpinBox()

        widget.setMinimum(-10)
        widget.setMaximum(10)

        widget.setPrefix("$")
        widget.setSuffix("c")
        widget.setSingleStep(1) # or e.g. 0.5 for QDoubleSpinBox
        widget.valueChanged.connect(self.value_changed)
        widget.textChanged.connect(self.value_changed_str)

        self.setCentralWidget(widget)

    def value_changed(self, i):
        print(i)

    def value_changed_str(self, s):
        print(s)

app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()


