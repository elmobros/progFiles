import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPalette, QColor
from PyQt5.QtWidgets import (
	QApplication,
	QHBoxLayout,
	QLabel,
	QMainWindow,
	QPushButton,
	QStackedLayout,
	QVBoxLayout,
	QWidget,
)

# from layout_colorwidget import Color

class MainWindow(QMainWindow):
	def __init__(self):
		super().__init__()

		self.setWindowTitle("My App")

		# defining page and button layouts
		pagelayout = QVBoxLayout()
		button_layout = QHBoxLayout()
		self.stacklayout = QStackedLayout()

		# adding the layouts
		pagelayout.addLayout(button_layout)
		pagelayout.addLayout(self.stacklayout)

		# create the red button, add a signal, 
		# add button to btn and stack layouts
		btn = QPushButton('red')
		btn.pressed.connect(self.activite_tab_1)
		button_layout.addWidget(btn)
		self.stacklayout.addWidget(Color('red'))

		# Repeat for the green and yellow buttons

		btn = QPushButton('green')
		btn.pressed.connect(self.activite_tab_2)
		button_layout.addWidget(btn)
		self.stacklayout.addWidget(Color('green'))

		btn = QPushButton('yellow')
		btn.pressed.connect(self.activite_tab_3)
		button_layout.addWidget(btn)
		self.stacklayout.addWidget(Color('yellow'))


		# set up the MainWindow Widget
		widget = QWidget()
		widget.setLayout(pagelayout)
		self.setCentralWidget(widget)


		# Need 3 slots (functions) to connect to the three signals from 
		# each button created above

	def activite_tab_1(self):
		self.stacklayout.setCurrentIndex(0)

	def activite_tab_2(self):
		self.stacklayout.setCurrentIndex(1)

	def activite_tab_3(self):
		self.stacklayout.setCurrentIndex(2)

class Color(QWidget):
	def __init__(self, color):
		super(Color, self).__init__()
		self.setAutoFillBackground(True)

		palette = self.palette()
		palette.setColor(QPalette.Window, QColor(color))
		self.setPalette(palette)


app = QApplication(sys.argv)

window = MainWindow()
window.show()
app.exec()






