import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPalette, QColor
from PyQt5.QtWidgets import (
	QApplication,
	QHBoxLayout,
	QLabel,
	QMainWindow,
	QPushButton,
	QStackedLayout,
	QVBoxLayout,
	QTabWidget,
	QWidget,
)

# from layout_colorwidget import Color

class MainWindow(QMainWindow):
	def __init__(self):
		super().__init__()

		self.setWindowTitle("My App")

		tabs = QTabWidget()
		tabs.setTabPosition(QTabWidget.West)
		tabs.setMovable(True)
		tabs.setDocumentMode(True)

		for n, color in enumerate(['red','green','blue','yellow']):
			tabs.addTab(Color(color),color)

		self.setCentralWidget(tabs)


class Color(QWidget):
	def __init__(self, color):
		super(Color, self).__init__()
		self.setAutoFillBackground(True)

		palette = self.palette()
		palette.setColor(QPalette.Window, QColor(color))
		self.setPalette(palette)


app = QApplication(sys.argv)

window = MainWindow()
window.show()
app.exec()






