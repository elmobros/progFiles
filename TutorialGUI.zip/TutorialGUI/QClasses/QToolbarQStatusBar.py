import sys
from PyQt5.QtWidgets import (
	QMainWindow, QApplication,
	QLabel, QToolBar, QAction, QStatusBar, QCheckBox
)
from PyQt5.QtGui import QIcon
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):

	def __init__(self):
		super(MainWindow, self).__init__()

		self.setWindowTitle("My App")

		label = QLabel("Hello!")
		label.setAlignment(Qt.AlignCenter)

		self.setCentralWidget(label)

		# create and add the toolbar
		toolbar = QToolBar("My Main Toolbar")
		self.addToolBar(toolbar)

		button_action = QAction(QIcon("acorn.png"),"Your button", self) # the button for the toolbar
		button_action.setStatusTip("This is your button") # status bar tip
		button_action.triggered.connect(self.onMyToolBarButtonClick) # connect signal with slot
		button_action.setCheckable(True) # toggle the toolbarbutton
		toolbar.addAction(button_action)

		toolbar.addSeparator()

		button_action2 =QAction(QIcon("bug.png"),"Your &button2", self)
		button_action2.setStatusTip("This is your button2")
		button_action2.triggered.connect(self.onMyToolBarButtonClick)
		button_action2.setCheckable(True)
		toolbar.addAction(button_action2)

		toolbar.addWidget(QLabel("Hello"))
		toolbar.addWidget(QCheckBox())

		self.setStatusBar(QStatusBar(self))

	# slot for the tool bar button
	def onMyToolBarButtonClick(self, s):
		print("click",s)



app = QApplication(sys.argv)
w = MainWindow()
w.show()
app.exec()