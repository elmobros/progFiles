import sys

from PyQt5.QtWidgets import ( QLabel,
	QApplication, QMainWindow, QPushButton, QDialog, QDialogButtonBox
)
from PyQt5.Qt import QVBoxLayout

class MainWindow(QMainWindow):
	def __init__(self, parent=None):
		super().__init__()

		self.setWindowTitle("My App")

		button = QPushButton("Press me for a dialog!")
		button.clicked.connect(self.button_clicked)
		self.setCentralWidget(button)

	def button_clicked(self,s):
		print("click",s)

		dlg = CustomDialog(self) # requires "self" for this function
		if dlg.exec():
			print("Success!")
		else:
			print("Cancel!")


# make a subclass for the dialog box

class CustomDialog(QDialog):
	def __init__(self, parent):
		# adding parent here is supposed to make dialobBox showup centerd on
		# Qmainwindow, it works with "parent" in line 34 and 31, and also in CustomDialog(parent)
		# in line 21 above. This must setup the child=parent window relation. 
		super().__init__(parent) 

		self.setWindowTitle("Hello!")

		QBtn = QDialogButtonBox.Ok | QDialogButtonBox.Cancel

		self.buttonBox = QDialogButtonBox(QBtn)
		self.buttonBox.accepted.connect(self.accept)
		self.buttonBox.rejected.connect(self.reject)

		self.layout = QVBoxLayout()
		message = QLabel("Something happened, is that OK?")
		self.layout.addWidget(message)
		self.layout.addWidget(self.buttonBox)
		self.setLayout(self.layout)

	# 	self.centerPos()

	# def centerPos(self):
	# 	qr = MainWindow.window(self).frameGeometry()
	# 	x = (qr.width() - self.width())/2
	# 	y = (qr.height() - self.height())/2
	# 	self.move(x,y)

app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()