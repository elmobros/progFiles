import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget
from PyQt5.QtGui import QPalette, QColor
from PyQt5.Qt import QHBoxLayout, QVBoxLayout

class MainWindow(QMainWindow):

    def __init__(self):
        super(MainWindow, self).__init__()
        self.setWindowTitle("My App")

        layout1 = QHBoxLayout()
        layout2 = QVBoxLayout()
        layout3 = QVBoxLayout()

        # First column (left)
        layout2.addWidget(Color('red'))
        layout2.addWidget(Color('white'))
        layout2.addWidget(Color('blue'))
        layout2.addWidget(Color('white'))
        layout2.addWidget(Color('red'))

        # add first column to the whole layout
        layout1.addLayout(layout2)

        # Second Column (Middle)
        layout1.addWidget(Color('green'))

        # Third Column (Right)
        layout3.addWidget(Color('red'))
        layout3.addWidget(Color('black'))
        layout3.addWidget(Color('purple'))

        # add the third column to the whole layout
        layout1.addLayout(layout3)

        # set layout margins
        layout1.setContentsMargins(0,0,0,0)

        #set the spacing between elements (for HBox)
        layout1.setSpacing(20)

        widget = QWidget()
        # add the whole layout to the mainwindow/widget
        widget.setLayout(layout1)
        self.setCentralWidget(widget)


class Color(QWidget):

    def __init__(self, color):
        super(Color, self).__init__()
        self.setAutoFillBackground(True)

        palette = self.palette()
        palette.setColor(QPalette.Window, QColor(color))
        self.setPalette(palette)



app = QApplication(sys.argv)

window = MainWindow()
window.show()
app.exec()
