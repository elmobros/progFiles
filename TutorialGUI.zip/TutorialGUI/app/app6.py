import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton
from PyQt5.QtWidgets import QLabel, QTextEdit, QVBoxLayout, QWidget
from PyQt5.QtCore import Qt
from random import choice


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

                

        self.label = QLabel("Click in this window")
        self.setCentralWidget(self.label)
        
    def mouseMoveEvent(self,e):
        self.label.setText("mouseMoveEvent")

    def mousePressEvent(self,e):
        self.label.setText("mousePressEvent")

    def mouseReleaseEvent(self, e):
        self.label.setText("mouseReleaseEvent")

    def mouseDoubleClickEvent(self,e):
        self.label.setText("mouseDoubleClickEvent")
        self.setMouseTracking(True)

                
app = QApplication(sys.argv)

window = MainWindow()
window.show()

app.exec()
