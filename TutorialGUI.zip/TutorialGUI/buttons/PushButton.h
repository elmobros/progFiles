"""
this is a module for a class for QWidget of the form

class ClassWidget(QWidget):

	to see how an externally imported, class/custom defined widget can be work

Filename: ClassWidget.py

"""

import sys
from PyQt5.QtWidgets import (
    QMainWindow, QApplication,
    QLabel, QCheckBox, QComboBox, QListWidget, QLineEdit, QWidget,
    QSpinBox, QDoubleSpinBox, QSlider,QVBoxLayout, QWidget, QPushButton
)
from PyQt5.QtCore import Qt

# class ClassWidget(QPushButton):

# 	def __init__(self):
# 		super(ClassWidget, self).__init__()


class PushButton(QPushButton):
	def __init__(self):
		super(PushButton,self).__init__()

		



