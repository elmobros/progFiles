def strike(text):
    return ''.join([u'\u0336{}'.format(c) for c in text])

def strike2(text):
    result = ''
    for c in text:
        result = result + c + '\u0336'
    return result

string = '\u0336' +'u'
print(string)
print (u'u+\u0335')
print(u'po\u030Cm')

newstring = strike2('asdf')
print(newstring)
smallstring = newstring[1:4]
print(smallstring)

print(u'u\u0330')
print(u'u\u0335')
# >>> print(strike('this should do the trick'))
# '̶t̶h̶i̶s̶ ̶s̶h̶o̶u̶l̶d̶ ̶d̶o̶ ̶t̶h̶e̶ ̶t̶r̶i̶c̶k'