"""
Classes 

from 
https://docs.python.org/3/tutorial/classes.html
Section  9 Classes

Classes provide a means of bundling data and functionality together
creating a new class creates a new type of object, allowing new instances
of that type to be made.  Each class instance can have attributes
attached to it for maintaining its state.  Class instances can also have 
methods (defined by its class) for modifying its state.

Compared with other programming languages, python's class mechanism adds classes
with a minimum of new syntax and semantics.  It is a mixture of the class mechanisms found
in C++ and modula-3. Python classes provide all the standard features of Object Oriented
programming:  the class inheritance mechanism allows multiple base classes, a derived
class can override any methods of its base class or classes, and a method can call the 
method of a base class with the same name.  Objects can contain arbitrary amounts and
kinds of data.  As is true for mdules, classes partake of the dynamic nature of python:
they are created at runtime, and can be modified further after creation.

In C++ terminology, normally class members (including data members) are public (except
see below Private Variables), and all member functions are virtual.  As in Modula 3,
there are no shorthands for referencing the object's members from its methods: the method
function is declared with an explicit first argument representing the object, which is
provided implicitly by the call.  As in Smalltalk, classes themselves
are objects.  This provides semantics for importing and renaming.  Unlike C++ and modula 3, 
built-in types can be used as base classes for extension by the user.  Also, like in C++
most built in operators with special syntax (arithmetic operators, subscripting, etc.)
can be redefined for class instances.

(Lacking universally accepted terminology to talk abotu classes, we will make occasional 
use of Smalltalk and C++ terms.  We would use modula 3, since its object-oriented OO 
semantics are closer to those of python than C++, but we expect that few readers have 
heard of it.)

Section 9.1 word about names andf objects

Objects hace individuality, and multiple names can be bound to the same object.  This
is known as aliasing in other languages.  This is usually not appreciated on a first
glance at Python, and can be safely ignored when dealing with immutable basic types
(numbers, strings, tuples).  How ever aliasing has a possibly surprising effect on 
the semantics of python code involving mutable objects such as lists, dictionaries,
and most other types.  THis is usually used to the benefit of the program, since
aliases behave like pointers in some respects.  For example, passing an object is cheap 
since only a pointer is passed by the implementation.  and, if a function modifies
an object passed as anagrument, the caller will see the change.  This eliminates the 
need for two different argument passing mechanisms as in Pascal (eg).

Section 9.2 Python scopes and namespaces

before introducing classes, we first have to know something about python's scopes rules. 
Class definitions play some neat tricks with namespaces, and you need to know how
scopes and namespaces work to fully understand what's going on.  Incidentally, knowledge
about this subject is useful for any advanceed python programmer.

Let's begin with some defintions.

Namespace - is a mapping from names to objects.  Most namespaces are currently implemented as 
python dictionaries, but that's normally not noticeable in any way (except for performance), 
and it may change in the future.  examples of namespaces are:
set of builtin names (containing function like abs())
set of builtin exception names
global names in a module
local names in a function invocation

In a sense the set of attributes of an object also form a namespace.  The important thing to 
know about namespaces is that there is absolutely no relation between names in different namespaces;
for instance, two different modules may both define a function 'maximize' without confusion - users of the 
modules must prefix it with the module name.

BTW, we use the word 'attribute' for anyt name following a dot - e.g. in the expression 'z.real'
 'real' is an attribute of object 'z'.  Strictly speaking, references to names in modules are 
 attribure references: in the expression modname.funcname, modname is a module object and funcname is an 
 attribute of it.  In this case, there happens to be a straightforward mapping between the module's
 attributes and the global names defined in the module: they share the same namespace.

 Attributes may be readonly or writable.  In the latter cxase, assignment to attributes is possible.
 Module attributes are writable: you can write modname.the_answer = 42.  Writable attributes may also
 be deleted with the del statement.   e.g. del modname.the_answer will remove the attribute the_answer
 from the object named by modname.

 Namespaces are created at different moments and have different lifetimes.  The namespace containing 
 the builtin names is created when the python interpreter starts up, and is never deleted.  The
 global namespace for a module is created when the module definition is read in; normally, module 
 namespaces also last untili the interpreter quits.  The statments executed by the top-level invocation
 of the interpreter, eith er read from a script file or interactively, are considered part of a 
 module called __main__, so they have their own global namespace.
 (builtin names actually also live in a module; this is called builtins)

 The local namespace for a function is created when the function is called, and deleted when the
 function returns or raises as exception that is not handled within the function. (Actually, forgetting
 would be a better way to describe what actually happens.)  Of course, recursive invocations each have their
 own local namespace.

 a SCOPE is a textual region of a python promgra where a namespace is directly accessible.  
 "directly accessible" here means that an unqualified reference to a name attempts to find
 the name in the namespace.

 Although scopes are determined statically, they are used dynamically.  At any time during the execution, there
 are 3 or 4 nested scopes whose namespaces are directly accessible:
 - the innermost scope, which is searched first, contains the local names
 - scopes of any enclosing functions, which are searched starting with the nearest enclosing scope,
 contains non-lcoal, but also non global names
 - the next to last scope contains the current module's global names
 -the outermost sopce (searched last) is the namespace containin builtin names

 If a name is declared global, then all references and assignments go directly to the middle scope
 containing the module's global names. To rebind variables found outside of the innermost scope,
 the nonlocal statement can be used; if not declared nonlocal, those variables are readonly
 (an attempt to write to such a variable will simply create a new local variable in the innermost
 scope, leaving the identically named outer variable unchanged).

 Usually, the local scope references the local names of the (textually) current function.  Outside
 functions, the local scope references the same namespace as the global scopeL the nmodules' namespace.  
 Class definitions place yat another namespace in the local scope.

 It is important to realize that scopes are determined textually: the global scope fo a function
 defined in a module is that module's namespace, no matter from where of by what alias the function is 
 called.  On the other hacen,m the actual saerch for names is done dynamically, at run time, however, the language
 defintion is evolving towards static name resolution, at "complie time". so don't rely on dynamic name resolution!
 (in fact, local variables are alreadyt determined statically)

 A special quirk of python is that - if no global or nonlocal statement is in effect - assignments
  to names always go into the innermost scope.  Assignments do not copt data - they just bind names
   to objects.  the same is true for deletions: the del statement del x removes the binding of x from the namespace
   referenced by the local scope.  in fact, all operations that introduce new names use the local scope:
   in particular, import statements ant function definitions bind the mnodule or function name in the 
   local scope.

   The global statement can be used to indicate that particular variables live in the global scope
   and should be rebound there; the nonlocal statment indicates that particular variables live
   in an enclosing scope and should be rebound there.

   Section 9.2.1 Scopes and namespaces example

   this is an example demonstration how to reference the different scopes and namespaces, and how
   global and nonlocal affect variable binding:
"""

def scope_test():
	def do_local():
		spam = "local spam"

	def do_nonlocal():
		nonlocal spam
		spam = "nonlocal spam"  # this supercedes the local assignment

	def do_global():
		global spam
		spam = "global spam"	# this supercedes the nonlocal assignment/module level

	spam = "test spam"
	do_local()
	print("After local assignment:", spam)
	do_nonlocal()
	print("After nonlocal assignment:", spam)
	do_global()
	print("After global assignment:", spam)

scope_test()
print("In global scope:", spam)
"""
Note how the local assignment (which is default) didn't change scope_test's binding of spam.
The nonlocal assignment changed scope_test's binding of spam, and the global assignment changed the 
module-level binding.

You can also see that there was no previous binding for spam before the global assignment.
"""

"""
Section 9.3 First look at classes

Classes introduce a little bit of new syntax, three new object types and some new semantics

Section 9.3.1 Class defintion syntax

class ClassName:
	<statement-1>
	.
	.
	.
	<statement-N>

Class defintions, like function definitions (def statements) must be executed
before they have any effect.  (You could conceivably place a class definition in a
branch of an if statement, of inside a fucntion)

In practice, the statements inside a class definition will usually be function defintions
but other statements are allowed and sometimes useful.  The function definitions 
inside a class normally have a peculiar form of argument list, dictated by the calling
conventions for methods - these are explained later.

When a class defintion is eneter, a new namespace is created and used as the local scope - 
thus, all assignments to local variables go into this new namespace.  In particular, 
function definitions bind the name of the new function there.

When a class definition is left normally, via the end, a class object is created.  This
is basically a wrapper around the contents of the namespace created by the class definition;
we'll learn more about class objects in the next section.  The original scope (the one in
effect just before the class definition was entered) is reinstated, and the class
object is bound here to the class name given in the class definition header
(ClassName in the example)

Section 9.3.2 Class objects

Class Objects support two kinds of operations: attribute references and instantiation.

Attribute references use the standard syntax used for all attribute references in python:
obj.name.  Valid attribute names are all the names that were in the class's namespace
when the class object was created.  SO, if the class definition looked like this:
"""
"""
class MyClass:
    # A simple example class
    i = 12345 

	def f(self):
		return 'hello world'

"""

"""
then MyClass.i and MyClass.f are valid attribute references, returning an integer and
a function object, respectively.  Class attributes can also be assigned to, so 
you can change the value of MyClass.i by
assignment.  __doc__ is also a valid attribute, returning the docstring belonging to the
class: "A simple example class"


Class instantiation uses the function notation.  Just pretend that the class object is
a parameterless function that returns a new instace of the class.  For example
(assuming the above class)

x = MayClass()

creates a new instance of the class and assigns this object to the local variable x.

The instantiation operation ("calling" a class object) creates and empty object.
Many classes like to create objects with instances customized to a specific initial state.
Therefore, a class may define a special method named __init__(), like this:

def __init__(self):
	self.data = []

When a class defines an __init__() method, class instatiation automatically invokes
__init__() for the newly-created class instance.  So in this example, a new, 
initialized instance can be obtained by:

x = MyClass()

Of course, the __init__() method may have arguments for greater flexibility. In that case,
arguments given to the class instantiation operator are passed on to __init__().

For example,

class Complex:
	def __ini__(self, realpart, imagpart):
		self.r = realpart
		self.i = imagpart

x = Complex(3.0,-4.5)
x.r, x.i
OUTPUT --->  (3.0,-4.5)

Section 9.3.3 Instance Objects

Nowe what can we do with instance objects?  The onlu operations understood by instance objects
are attribut references.  THere two kinds of valid attribute names: data attributes and methods.

data attributes correspond to "instance variables" in Smalltalk and to "data members" in C++.
Data attritbutes need not be declared; like local variables, they spring into existence
when they are first assigned to.  For example, if x is the instance of MyClass created above,
the following piece fo code will print the value 16, withou leaving a trace:

x.counter = 1
while x.counter < 10:
	x.counter = x.counter*2
print(x.counter)
del x.counter

The other kind of instance attribute reference is a method.  A method is a 
function that "bleongs to " and object.  (in python, the term method is not unique
to class instances: other object types can have methods as well.  For example, 
list objects have methods called append, insert, remoce, sort, and so on.  However
in the following discussion, we'll use the term method exclusively to mean methods of 
class instance objects, unless explicitly stated otherwise.)

Valid method names of an instance obect depend on its class.  By definition, all attributes
of a class that are function objects define corresponding methods of its instances.
So in our example, x.f is a valid method reference, since MyClass.f is a function,
but x.i is not, since MyClass.i is not.  but, x.f is not the same thing as MyClass.f --
it is a method object, noa function object.

Section 9.3.4 Method Objects

Usually a method is called right after its bound:

x.f()

In the MyClass example, this will return the string 'hello world'.  However, it is not
 necessary to call a method right away: x.f is a method object, and can be stored
 away and called at a later time. For example:

 xf = x.f
 while True:
 	print(xf())

 that will continue to print 'hello world' until the end of time.

 What exactly happens when a method is called?  You mayu have noticed that x.f() was 
 called without an argument above, even though the function definition for f() specified
 an argument.  What happened to the argument? Surely python raises an exception when a 
 function that requires an argument is called without any - even if the argument isn't 
 actually used...

 Actually, you may have guessed the answer: the special thing about methods is that
 the instance object is passed as the first argument of the function.  In our example, the 
 call x.f() ius exactly equivalent to MyClass.f(x).  In general, calling a method with a list
 of n arguments is equivalent to calling the corresponding function
 with an argument list that is created by inserting the method's instance object before the
 first argument.

 If you still don't understand how methods work, a look at the implementation can perhaps
 clarify matters.  When a non-data attribute of an instance is referenced, the instance's 
 class is searched.  If the name denotes a valid class attribute that is 
 a function object, a method object is created by packing (pointers to) the instance
 object and the function object just found together in an abstract object: this is the 
 method object.  When the method object is called with an argument list is 
 constructed from the instance object and the argument list, and teh function object
 is called with this new argument list.

Section 9.3.5 Class and Instance Variables

Generally speaking, instance variables are for data unique to each instance and
class variables are for attributes and methods shared by all instances of the class

class Dog:

	kind = 'canine'   # class variable shared by all instances

	def __init__(self, name):
		self.name = name    # instance variable unique to each instance

OUTPUT:

>>> d = Dog('Fido')
>>> e = Dog('Buddy')
>>> d.kind              # shared by all dogs
'canine'
>>> e.kind              #shared by all dogs
'canine'
>>>d.name              # unique to d
'Fido'
>>>e.name              # unique to e
'Buddy'

As discussed in A Word About Names and Objects, shared data can have possibly
surprising effects with involving mutable objects such as lists and dictionaries.
For example, the tricks list in the following code should not be used as a class variable
because just a single list would be shared by all Dog instances.

class Dog:

	tricks[]       # mistaken use of a class variable

	def __init__(self,name):
		self.name = name

	def add_trick(self,trick):
		self.tricks.append(trick)


>>>d = Dog('Fido')
>>>e = Dog('Buddy')
>>>d.add_trick('roll over')
>>>e.add_trick('play dead')
>>>d.tricks                  # unexpectedly shared by all dogs		
['roll over', 'play dead']

Correct design of the class should use an instance variable instead:

class Dog:

	def __init__(self,name):
		self.name = name
		self.tricks = []      # creates a new empty list for each dog

	def add_trick(self,trick):
		self.tricks.append(trick)

>>>d = Dog('Fido')
>>>e = Dog('Buddy')
>>>d.add_trick('roll over')
>>>e.add_trick('play dead')
>>>d.tricks
['roll over']
>>>e.tricks                 	
['play dead']
	



"""

