kirk = ["James Kirk", 34, "Captain",2265]
spock = ["Spock",35, "Science Officer", 2254]
mccoy = ["Leonard McCoy", "Cheif Medical Officer", 2266]
