# parent example is class Dog
class Dog:
    # Class attribute
    species = "Canis familiaris"

    def __init__(self,name, age):  # breed argument input has been removed for child classes below
        self.name = name
        self.age = age
    #   self.breed = breed     # this is commented for the creation of the child classes below

    def __str__(self):
        return f"{self.name} is {self.age} years old"

    def speak(self, sound):   # we use the function super() to call this inside of 
                               # class JackRussellTerrier
        # we will change the string for this method
        # to show that this change will 
        # propagate to the child class
        #   return f"{self.name} says {sound}"
        return f"{self.name} barks: {sound}"


#   child classes derived from the parent class Dog

class JackRussellTerrier(Dog):
    # extending functionaltiy of the parent class 
    # by adding a method for this child class
    # naming this method with the same name as the 
    # parent class in the child class
    # overrides the definition of the 
    # method  
    # NOW what we will do is to 
    # make sure don't lose nay changes from 
    # Dog.speak()
    # to do this we use the super() function
    # to call the speak() method of the parent
    def speak(self,sound="Arf"):
        return super().speak(sound)  # this line includes super(),  
                                     # this ensures we call .speak()
                                    # from class Dog above


class Dachshund(Dog):
    pass

class Bulldog(Dog):
    pass
