"""""
from realpython.com

Introduction to Object Oriented Program OOP

OOP is a method of structing a program by building related properties and behaviors into individual OBJECTS.

This tutorial, will learn:

    basics of OOP in python

Conceptually, OBJECTS are like the components of a system.  Think of a program as a factory assembly line of sorts.  At each step of the assempbly line a system component processes
some material, ultimately transforming raw material into a finished product.


An OBJECT contains data, like the raw or preprocessed materials at each step on an assembly line, and behavior, like the action each assembly line component performs.

You will learn HOW TO:

    CREATE A CLASS which is like a blueprint for creating an object
    use classes to CREATE NEW OBJECTS
    model systems with CLASS INHERITANCE

WHAT IS OPP IN PYTHON?

OOP is a promgramming paradigm that provides a means of structuring programs so that properties and behaviors are bundled into 
individual OBJECTS.

For instance, an OBJECT could represent a person with PROPERTIES like a name, age, and address and BEHAVIORS such as walking, talking, breathing, and running.

Or it could represent an email with PROPERTIES like a recipient list, subject, and body and behaviors like adding attachments and sending.

Put another wy, OPP is an approach for modeling concrete, real-world things, like cars as well as relations between things, like companies and employees, students and teachers and so on.  OOP models real world 
entities as software objhects that have some data associated with them and can perform certain functions.

Another common programming paradigm is Procedural Programming PP, which structures a program like a recipe in that it provides a set of steps, in the form of functions and code blocks,
that flow sequentially in order to complete a task.

The key takeaway here is that OBJECTS are at the center of OOP in python.  not only representing the data, as in PP, but in the overall structure of the program as well.

###############################      DEFINE A CLASS IN PYTYHON          ####################################

Primitive data structures - like numbers, strings, and lists - are designed to represent simple pieces of information, such as the cost of an apple, the name of a poem, or your favorite colors, your credit card number, etc.  What if you 
wawnt to represent something more complex??

For example, let's say you want to track employees in an orgranization.  You need to store some basic information about each employee, such as their name, age, position, and the year they started working.
One way to fo this is to represent each employee as a list:



See classesEx1.py for the list

There are a number of issues with this approach.

First it can make larger code files more difficult to manage.  If you reference kirk[0] several times away from where the kirk list is declard, will you remember that the element with index 0 is the employee's name?

Second, it can introduce errors if not every employess has the same number of elements in the list.  In the mccoy list above, the age is missing, so mccoy[1] will return "Chief Medical Officer" instead of his age.

A great way to make this type of code more manageable and more maintainable is to use CLASSES.

################################      CLASSES VS INSTANCES #############################################

CLASSES are used to create user-defined data structures.  CLasses define functions called METHODS, which ID the behaviors and actions that an object created from the class can perform with its data.

In this tutorial, you'll create a Dog class that stores some information about the characterisstics and behaviors that an individual dog can have.  A CLASS is a blueprint for how something should be defind.  It doesn't
actually contain any data.  The Dog class specifies that a name and an age are necessary for defining dog, but it doesn't contain the name or age of any specific dog.

While the CLASS is the blueprint, an INSTANCE is an object that is built from a lcass and contains real data.  An instance of the Dog class is not a blueprint anymore.  It's an actual dog with a name, with an age.
Put another way, a CLASS is like a form or questionnaire.  An INSTANCE is like a form that has been filled out with information.  Just like many people can fill out the same form with their own unique information, may instances
can be created from a single class.


###################################     HOW TO DEFINE A CLASS #################################

All class definitions start with the 'class' keyword, which is followed by the name of the class and a colon.  Any ocde that is indented below the class definition is considered part of the class's body.

Here's an example:   see classesEx2.py



The body of the Dog class consists of a single statement: the 'pass' keyword.  'pass' is often used as a placeholder indicating  where code will eventually go.  It allows you to run this code without the python throwing an error.
 
 NOTE: Python class names are writted in CaptializedWords notation by convention.  For example, a class for a specific breed of dog like the Jack Russell Terrier would be written as JackRussellTerrier.

 The Dog class isn't very interesting right now, so let's spruce it up a bit by defining some properties that all dogs should have.  THere are a number of properties we can choose from , including name age, coat color, and breed.
 To keep things simple, we'll just use name and age.

 The properties that all Dog objects must have are defined in a METHOD called    .__init__() initializes each new instance of the class.
 That is, .__init__() initializes each new instance of the class.

You can give .__init__() any number of parameters, but the first parameter will always be a variable called self.  When a new class instance is created, the instance is automatically passed to the self parameter in
.__init__() so that new ATTRIBUTES can be defined on the object.

Let's update the Dog class with an .__init() method that creates .name and .age attributes>

See same file classesEx2.py
Notice that .__init__() method's signature is indented four spaces.  The body of the method is indented by eight space.  This indentation is vitally important.  It tells python that .__init__() method belongs to the Dog class.

In the body of .__init(), there are two statements using the self variable:
    1. self.name = name    creates an attribute called name and assigns to it the value of the parameter name
    2. self.age = age      creates " "  " age " " " " " " " " " " age

Attributes created in .__init__() method are called INSTANCE ATTRIBUTES.  An instance attribute's value is specific to a particular instance of the class.  All Dog objects have a name and an age, but the vlalues for the name
and age attributes will vary depending on the Dog instance.

On the other hand, CLASS ATTRIBUTES are attributes that have the same value for all class instances.  You can define a class attribure by assigning a value to a variable name outside of .__init__()

For example, the following Dog class has a class attribute called species with the value "Canis familiaris":
    see same example .py doc

Class attributes are defined directly beneath the first line of the class name and are indented by four spaces.  They must always be assigned an initial value. When an instance of the class is created, class attributes are automatically 
created and assigned to their initial values.

Use class attributes to define properties that should have the same value for every class instance.  Use instance attributes for properties that vary from one instance to another.

Now that we have a Dog class, let's create some dogs!


#####################   Instantiate an Object in Python   ###################################################



Open IDLE's interactice window and type the following:

class Dog:
    pass


This creates a new Dog class with no attributes or methods.  Creating a new ojbect from a class is called instantiating an object.  You can instantiate a new Dog object by typing the name of the class, followed by opening
and closing parentheses:
    
#>>> Dog()
#<__main__.Dog object at 0x106702d30>


The funny string is the memory address, it is where the Dog object is stored in the computer's memory.  Note that the address you see on your screen will be different.

This is indeed the case..

Each time Dog() is called, a new instance is created and is unique.

Once you update the class to have the following class attribute and two instance attributes

class Dog:
    species = "Canis familiaris"
    def __init__(self,name,age):
        self.name = name
        self.age = age

To instantiate objects of this Dog class, you need to provide values for the name and age.  If you don't, then python raises a TypeError


>>>Dog()
Traceback (most recent call last):
    File "<pyshell#6>", line 1, in <module>
        Dog()
TypeError: __init__() missing 2 required positional arguments: 'name' and 'age'

To pass arguments to the name and age parameters, you must put values into the parentheses after the class name

buddy = Dog("Buddy", 9)  for example
miles. = Dog("Miles", 4)

This creates two new Dog instances.

The Dog class's .__init__() method has three parameters, so why are only two arguments passed to it in the example?  

Well, for one thing, we already put self in the first parameter but also,

""""
when you instantiate a Dog object, Python creates a new instance and passes it ot the first paramter of ,__init__().  this essentially removes the self parameter, so you only need to worry about the name and age parameters.

After you crate the two Dog instances, you can access their instance attributes using dot notation:

    buddy.name
    'Buddy'
    buddy.age
    9
    etc.

    One of the biggest advantages of using classes to organize data is that instances are guaranteed to have the attributes you expect.  All Dog instances have .species, .name, and .age attributes,
    so you can use those attributes with confidence knowing that they will always return a value.

    Though attributes are guaranteed to exist, their values can be changed dynamically by assignment

    buddy.age = 10

    will now make this attribute 10
    buddy.age 
    will rturn 
    10

    You can even change the species by assigning miles.species to some other string

    The main thing here is that custom objects are mutable by default.  An object is mutable if it can be altered dynmically (its attributes).  For example, lists and dictionaries are mutable, but strings and tuples are immutable.



    ###########################                INSTANCE METHODS           ####################################################################

    INSTANCE METHODS are functions that are defined inside a class and can only be called from an instance of that class.  Just like .__init__(), an instance method's first parameter is always self.

    We create the follwing class for Dog

    class Dog:
        species = "Canis familiaris"

            def __init__(self, name, age):
                self.name = name
                self.age = age
            # Instance method
            def description(self):
                return f"{self.name} is {self.age} years old"
            # Another instance method
            def speak(self, sound):
                return f"{self.name} says {sound}"
                                                    
This Dog class has two instance methods:
    1.  .description() returns a string displaying the name and age
    2. .speak() has one parameter called sound and returns a string containing the dog's name and sound it makes

Save the modified dog class and run it


Exercise: Create a Car Class

see the file Exercise1.py for the solution

###################################     Inherit From Other Classes in Python  ####################################################

Inheritance is the process by which one class takes on the attributes and methods of another.  Newly formed classes are called CHILD CLASSES,
and classes that child classes are derived from are called PARENT CLASSES.

Child classes -  can ovveride or extend the attributes and methods of parent classes.  In other word, child classes inherit all of the parent's attributes
and methods but can also specify attributes and methods that are unique to themselves.

Although the analogy isn't perfect, you can think of onject inheritance sort of like genetic inheritance.

You can override or extend attributes.

Dog Park Example

Pretend you are at a dog park.  There are many dogs of different breeds at the park, all engaging in vairous dog behaviors.

Suppose now that you wnat to model the Dog park with Python classes.  The Dog class that we wrote in the previous section can distinguish dogs
by name and age but not by breed.

You could modify the Dog class by adding a .breed attribute:


The instance methods defined earlier are omitted here because they aren't important for this part.

You can also use the .speak() method but it's tedious because you must call
miles.speak(string)
everytime.  
You can simplify the experience of working with the Dog class by creating a child class for each breed of dog.  This allows you to extend the 
functionality that each child class inherits, including specifying a default argument for .speak()


########################      Parent vs Child Classes    ###################################

Let's create a child class for each of the three breeds mentioned above:
    Jack Russell Terrier
    Dachshund
    Bulldog

Remember, to create a child class, you create a new class with its own name and then put the name of the parent class in parentheses.  Add the following 
to the classesEx2.py file for the Dog class.

class JackRussellTerrier(Dog):
    pass

class Dachshund(Dog):
    pass

class Bulldog(Dog):
    pass

Generally, the syntax is

class childClassName(parentClassName):
    <statements, mnethods and attributes>
    .
    .
    .

So, now you can define or INSTANTIATE some of the dogs of specific breeds by using

miles = JackRussellTerrier("Miles",4)

as opposed to using the parent class that requires

miles = Dog("Miles",4,"Jack Russell Terrier")

These child classes inherit all of the attributes and methods of the parent class:

    miles.species

    for example, still outputs

    'Canis familiaris'


as well as other atts and methods from before.

But, now, to determine which class the dog belongs to, i.e. the breed,

we can use the type() function

type(jim)

with output 
<class '__main__.Bulldog'>

What if you want to determine if jim is also an instance of the Dog class?  Use the built-in isinstance() function

isinstance(jim,Dog)

OUTPUT  --->    True

Notice that isinstance() takes two arguments, an object and a class.  In the example above, isinstance() checks if jim
is an instance of the Dog class and returns True.

The objects miles, jim, buddy and jim are all objects that are all Dog instances, but miles is NOT a Bulldog instance,
and jack is NOT a Dachshund instance:

isinstance(miles, Bulldog)

with output False

Now more generally, all objects created from a child class are instances of the parent class, although they may not be
instances of other child classes.

Now that you've created child classes for some different breeds of dogs, let's give each breed its own sound.


############################      Extend the Functionality of a Parent Class    ################################

Since different breeds of dogs have slightly different barks, you want to provide a default value for the sound argument
of their respective .speak() methods.  To do this, you need to override .speak() in the class definition for each breed.

To override a method defined on the parent class, you define a method with the same name on the child class.  Here's what that
looks like for the JackRussellTerrier class:

class JackRussellTerrier(Dog):
    def speak(self, sound = "Arf"):
        return f"{self.name} says {sound}"

Now, .speak() is defined on the Jack Russell Terrier class with the default argument for sound set to "Arf".


We can still make the dog say something else by explicitly calling miles.speak("Grr") for example

One thing to keep in mind about class inheritance is that changes to the parent lcass automatically propagate to child classes.

THis occurs as long as the attribute or method being changed isn't overridden in the child class.

this means that for the other breed classes that haven't been changed, the change in the parent class will
propagate to the child class.  But, if the breed class was changed, the parent class change won't be affect the child class

For example, in the editor window, change the string returned by .speak() in the Dog class

class Dog:
    def speak(self,sound):
        return f"{self.name} barks: {sound}"



Old instances that remain before the change will stay with the child class method definition.

Sometimes it makes sense to completely override a method from a parent class.  But in this instance, we
don't want the JackRussellTerrier class to lose any changes that might be made to the formatting of the 
output string Dog.speak()

To do this, you still need to define a .speak() method on the child JackRussellTerrier class.

But instead of explicitly defining the output string, you need to call the Dog class's .speak()
inside of the child class's .speak() using the arguments that you passed to JackRussellTerrier.speak()

You can access the parent class from inside a method of a child class by using super()

class JackRussellTerrier(Dog):
    def speak(self,sound="Arf"):
        return super().speak(sound)

When you call super().speak(sound) inside JackRussellTerrier, Python searches the parent class, Dog, 
for a .speak() method and calls it with the variable sound.

We can now compile the updated file and run it to see that the change in class JackRussellTerrier has been made

NOte: in the above examples, the class hierarchy is very straightforward.  The JackRussellTerrier class has a single parent class, Dog.

In real-world examples, the class hiearchy can get quite complicated.

super() does much more than just search for the parent class for a method or an attribute.

It traverses the entire class hiearchy for a matching method or attribute.  If you aren't careful, super() can have surprising results.

###################      Check Your Understanding  ################################################################

The exercise is 

Create a GoldenRetriever class that inherits from the Dog class.  Give the sound argument of GoldenRetriever.speak()
a default value of "Bark".  Use the following code for your parent Dog class

Code is in the file classesEx3.py


"""



