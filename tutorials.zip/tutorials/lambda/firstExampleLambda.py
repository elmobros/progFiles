"""
firstExampleLambda.py
"""
"""
def identity(x):
	return x

this is standard python
 but this is lambda version

 lambda x: x


 """
full_name = lambda first, last: f'Full name: {first.title()} {last.title()}'
ans = full_name('guido', 'van rossum')
print(ans)