"""
Supercharge your classes with Python super()


While python isn't puerly an OOP language, it's flexible enough and powerful enough to allow you to build your applications using the OOP paradigm

One of the ways in whish python achieves this is by suppoorting inheritance, which it does with super() method

In this tutorial,

- the concept of inheritance in Python
- mulitple inheritance in Python
- how super() function works
- how super() function in single inheritance works
- how super() function in multiple inheritance works

###################### An overview of pythons super() function


If you have experience with OOP languages, you may already be familiar with the functionality of super()


If not, dont worry.  While the official docs are fairly technical, at a high level super() gives you access to methods in 
a superclass from the subclass that inherits from it.

super() alone returns a temporary object of the superclass that then allows you to call that superclass's methods

Why would you want to do any of this?  While the possiblities are limited by your imagination, a common use case is building
classes that extand the functionality of previously built classes.

Calling the previously built methods with super() saves you from needing to rewrite those
methods in your subclass, and allows you to swap
out superclasses with minimal code changes.

#######################################    super() in Single Inheritance

inheritance is a concept in OOP in which a class
derives (or inherits) attributes and behaviors from 
another class without needing to implement them
again.

For me at least, it's easier to understand these
concpets when looking at code, so let's write
classes describing some shapes:

see file "shapes.py"

The square is special case of a rectangle.  We can use inheritance to reflect this, and...

By using inheritance, we can reduce the amount of code we write.

See shapesSuper.py

In the code we use super().__init__() to allow use to use functions in class Rectangle
without repeating code.  The same functionality remains and the .area() methods work 
the same without fail.

In this example, Rectangle is the superclass and Square is the subclass.

Because the Square and Rectangle.__init__() methods are so similar, you can simply call the superclass's .__init__() method
( Rectangle.__init__() ) from that of Square by using super().  This sets the .length and .width attributes even though you
just had to supply a single length parameter to the Square contructor.

Construtor is a special method in Python that is called when instantiating an object using class definitions - e.g. __init__()

When you run the code, even though the Square class doesn't explicitly implement it, the call to .area() will use the .area()
method in the superclass and print "16".  The Square class Inherited .area() from the Rectangle class.

########### What can super() do for you?

So what can super() do for you in single inheritance?

Like in other OOPs, it allows you to call methods of the superclass
in your subclass.  The primary use case of this is to extend the
functionality of the inherited method.

In the example that will be shown, you will create a class Cube that inherits from Square and
extends the functionality of .area() inherited from the Rectangle class through Square, to 
calculate the surface area and volume of a Cube instance:

    See cube.py code

Here we implemented two methods for the Cube class, 
.surface_area()
.volume()

Both of these calculations rely on calculating the area of a single face,
so rather than reimplementing the area calculation
we just use super() to call it from the Rectangle class.

Also, notice that the Cube class defintion doesnt have
a .__init__() method.  Because Cube inherits from Square,
and .__init__() doesn't really do anything different
fro Cube than it already id for Square, we skipped
definined it.  And, the .__init__() of the superclass
Square will be called automatically.

super() returns a delegate object to a parent class, so you call the 
method you want directly on it: super().area()

Not only does this save from having to rewrite the area calculations, but it also 
allows ud to change the internal .area() logic in a single location.

This is especially handy when you have a number os sublcasses inheriting from one superclass

########### A super() deep dive

Before heading into multiple inheritances, let's take a quick detour into the mechanics of super()

While the examples above (and below) call super() without any parameters, super() 
can also take two parameters: first is the subclass and the
second parameter is an object that is an instance of that subclass.

First we will see what the first variable will do.

class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * self.length + 2 * self.width

class Square(Rectangle):
    def __init__(self, length):
        super(Square, self).__init__(length, length)

In python 3, the super(Square, self) call is equivalent to the parameterless super() call.

The first parameter refers to the subclass square, while the second parameter refers to a Square object 
which is itself in this case.  You can call super() with other classes as well:

_________________________________________________
class Cube(Square):
    def surface_area(self):
        face_area = super(Square, self).area()
        return face_area * 6

    def volume(self):
        face_area = super(Square, self).area()
        return face_area * self.length
_________________________________________________
In this example, you are setting Square as the subclass argument to super(), instead of Cube.

This causes super() to start searching for a mathcing method, .area() in this case, 
at one level above Square in the instance hierarchy, in this case Rectangle.

In this specific example, the behavior doesn't change.  But imagine that Square also
implemented an .area() method that you wanted to make sure Cube did not use.  Calling super() this
way allows you to do that.

What about the second parameter? Remember this is an object that is an instance of the class
used as the first parameter.  For example, isinstance(Cube, Square) must return True.

By including an instantiated object, super() returns a BOUND METHOD: a method that is bound 
to the object, which gives the method of the object's context such as any instance
attributes.  If this parameter is not included, the method returned is just a function,
unassociated with an object's context.

Note: Technically, super() doesn't return a method.  It returns a Proxy object.  This is an object
that delegates calls to the correct class methods without amaking an additional object in order to 
do so.

###############   super() in Mulitple inheritance

Now that we've worked through an overview and some examples of super()
and single inheritance, we will now look at
how multiple inheritances work and how super() enables that functionality

Multiple Inheritance Overview############

There is another use case in which super() really shines, and this one isn't as common as the single inheritance
scenario.  In addition to single inheritance, Python supports multiple inheritnace,
in which a subclass can inherit from multiple superclasses that
don't necessarily inherit from each other (also known as sibling classes)

______________               ________________
Super class 1                 Superclass 2
    |                           |
    |                           |
    |                           |
    |-->>>---- |Subclass|---<<<-|

To better illustrate multiple inheritance in action, here is some code to try out,
showing how to build a right pyramid out of a Triangle and a Square:

--------------------------------------------------------
class Triangle:
    def __init__(self, base, height):
        self.base = base
        self.height = height

    def area(self):
        return 0.5 * self.base * self.height

class RightPyramid(Triangle, Square):
    def __init__(self, base, slant_height):
        self.base = base
        self.slant_height = slant_height

    def area(self):
        base_area = super().area()
        perimeter = super().perimeter()
        return 0.5 * perimeter * self.slant_height + base_area
-----------------------------------------------------------------

Note: the slant height may be unfamiliar, esp. if it's been awhile since geometry

This example declares a Triangle class and a RightPyramid class that inherits from both Square and
Triangle.  You'll see another .area() method that uses super() just like a single inheritance, with 
the aim of it reaching the .perimeter() and .area() methods defined all the way up in the Rectangle class

NoteL you may notice that the code above isn't using any inherited properties from the Triangle class
yet.  Later examples will fully atake advantage of inheritance from both Triangle and Square.

The problem, though, is that both superclasses (Triangle and Square) define a .area()

Take a second and think about what might happen when you call .area() on RightPyramid, and
then try calling it like below:

>> pyramid = RightPyramid(2, 4)
>> pyramid.area()
Traceback (most recent call last):
  File "shapes.py", line 63, in <module>
    print(pyramid.area())
  File "shapes.py", line 47, in area
    base_area = super().area()
  File "shapes.py", line 38, in area
    return 0.5 * self.base * self.height
AttributeError: 'RightPyramid' object has no attribute 'height'

Did you guess that python will tyr to call Triangle.area()?  This is because of something called the method resolution order.

NoteL How did we notice that Triangle.area() was called and not, as we hoped, Square.area()?  If you look at the last line of the traceback, you'll 
see a reference to a specific line of code.

return 0.5 * self.base * self.height

You amy recognize this fromn the geometry class as the formula for the area of triangle.
Otherwise, you might have scrolled up to the Triangle and Rectangle class definitions and seen this same code
in Triangle.area()

Method Resolution Order MRO #####################

The MRO tells Python hwo to search for inherited methods.

This comes in handy when you're using super() because the MRO tells you exactly
where python will look for a method you're callinf with super() and
in what order

Every class has an .__mro__ attribute that allows us to inspect the order,
so let's do that
""""
>>> RightPyramid.__mro__
(<class '__main__.RightPyramid'>, <class '__main__.Triangle'>, 
 <class '__main__.Square'>, <class '__main__.Rectangle'>, 
 <class 'object'>)
"""

"""
This tells us that methods will be searched first in RightPyramid, then Triangle, then Square,
then Rectangle, then from which all classes originate.

The problem here is that the interpeter is searching for .area() in Triangle before Square.

And upon finding .area() in triangle, python calls it instead of the one we want.

Because Triangle.area() expects .height, we get 
an AttributeError

Luckily, we have some controal over ohow the MRO is constructed.  Just by changing the signature of the RightPyramid class
you can search in the order you want and the methods resolve correctly:

class RightPyramid(Square, Triangle):
    def __init__(self, base, slant_height):
        self.base = base
        self.slant_height = slant_height
        super().__init__(self.base)

    def area(self):
        base_area = super().area()
        perimeter = super().perimeter()
        return 0.5 * perimeter * self.slant_height + base_area

Now, we can again inspect the mro for the class

""""
>>> pyramid = RightPyramid(2, 4)
>>> RightPyramid.__mro__
(<class '__main__.RightPyramid'>, <class '__main__.Square'>, 
<class '__main__.Rectangle'>, <class '__main__.Triangle'>, 
<class 'object'>)
>>> pyramid.area()
20.0


You see that the MRO is now what you'd expect, and you can inspect the area of the pyramid
as well thanks to .area() and .perimeter()

There still is a problem here, though.  For the sake of simplicity, 
a few things were done incorrectly by the author. First, was that there were
two separare classes with the same method name and signature.

This causes issues with the MRO, because as we just saw, .area() was in two
different class definitions in mulitple hierarchy levels.

When you're using super() with mulitple inheritance, it's imperative to design your classes to COOPERATE.

Part of this is ensuring that your method are unique so that they get resolved
in the MRO, by making sure method signatures
are unique - whether by using method names or method
parameters.

In this case, to avoid a complete overhaul of code, you can rename the Triangle class's
.area() method to .tri_area().  This way, the area methods can continue
using the class properties rather than taking external parameters:

class Triangle:
    def __init__(self, base, height):
        self.base = base
        self.height = height
        super().__init__()

    def tri_area(self):
        return 0.5 * self.base * self.height

Let's go ahead and use this in the RightPyramid class:

class RightPyramid(Square, Triangle):
    def __init__(self, base, slant_height):
        self.base = base
        self.slant_height = slant_height
        super().__init__(self.base)

    def area(self):
        base_area = super().area()
        perimeter = super().perimeter()
        return 0.5 * perimeter * self.slant_height + base_area

    def area_2(self):
        base_area = super().area()
        triangle_area = super().tri_area()
        return triangle_area * 4 + base_area

The next issue here it that the code doesn't have a delegated Triangle object like it does for a Square
object, so calling .area_2() will give us an AttributeError since .base and .height don't have any values.

You need to do two things to fix this:

    1. All methods that are called with super() need to have a call to their 
    superclass's version ofd that method.  This means that you will need to add
    super().__init__() to the .__init__() methods of Triangle and Rectangle.

    2. Redesign all the .__init__() calls to take a keyword dictionary.  See the complete
    code below.


Complete Code----------------------------------------------------------
class Rectangle:
    def __init__(self, length, width, **kwargs):
        self.length = length
        self.width = width
        super().__init__(**kwargs)

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * self.length + 2 * self.width

# Here we declare that the Square class inherits from 
# the Rectangle class

"""
"""
class Square(Rectangle):
    def __init__(self, length, **kwargs):
        super().__init__(length=length, width=length, **kwargs)

class Cube(Square):
    def surface_area(self):
        face_area = super().area()
        return face_area * 6

    def volume(self):
        face_area = super().area()
        return face_area * self.length

class Triangle:
    def __init__(self, base, height, **kwargs):
        self.base = base
        self.height = height
        super().__init__(**kwargs)

    def tri_area(self):
        return 0.5 * self.base * self.height

class RightPyramid(Square, Triangle):
    def __init__(self, base, slant_height, **kwargs):
        self.base = base
        self.slant_height = slant_height
        kwargs["height"] = slant_height
        kwargs["length"] = base
        super().__init__(base=base, **kwargs)

    def area(self):
        base_area = super().area()
        perimeter = super().perimeter()
        return 0.5 * perimeter * self.slant_height + base_area

    def area_2(self):
        base_area = super().area()
        triangle_area = super().tri_area()
        return triangle_area * 4 + base_area
---------------------------------------------------------------------
There are a number of important differences in this code:

    - **kwargs is modified in some places (such as RightPyramid.__init__()): ** this will allow
    users of these objects to instantiate them only with the arguments that make sense for 
    that particular object.

    - Setting up named arguments before **kwargs:  You can see this in RightPyramid.__init__(). This has the neat effect of
    popping that key right out of **kwargs dictionary, so that by the time that it ends up at the end of the 
    MRO in the object class, **kwargs is empty.


Note: Following the state of kwargs can be tricky here, so here's a table of .__init__()
calls in order, showing the class that owns the call, and the contents of kwargs during the
call:


    Class 	Named Arguments 	kwargs
RightPyramid 	base, slant_height 	
Square 	length 	base, height
Rectangle 	length, width 	base, height
Triangle 	base, height

Now when you use these updated classes, you have this:

""""
>>> pyramid = RightPyramid(base=2, slant_height=4)
>>> pyramid.area()
20.0
>>> pyramid.area_2()
20.0

It works, you used super() to navigate a completed class hierarchy while using both single and multiple class inheriatnce and composition
to create new classes with minimal reimplementation.





"""



















































"""
